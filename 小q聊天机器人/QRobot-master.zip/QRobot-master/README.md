# QRobot

小Q聊天机器人

CSDN博客：http://blog.csdn.net/baiyuliang2013

**注意：发送消息后如果小Q没回答，或回答“亲爱的，当天请求次数已用完”，表示当天的api调用次数已经超过限制次数，大家可以自己申请apikey用于测试！（音乐和位置功能不受影响）**

**另：对于音乐失效问题，可参考本人此篇博客，更换搜索方法：**
[http://blog.csdn.net/baiyuliang2013/article/details/51496620](http://blog.csdn.net/baiyuliang2013/article/details/51496620)

**应用市场线上版体验：**

apk安装包：[点我下载](http://openbox.mobilem.360.cn/index/d/sid/3282870)

![扫码下载](http://img.blog.csdn.net/20160601164742841)

**360**
360应用地址：http://zhushou.360.cn/detail/index/soft_id/3282870

**应用宝**
应用宝应用地址：http://android.myapp.com/myapp/detail.htm?apkName=com.byl.qrobot

**百度**
百度应用地址：http://shouji.baidu.com/software/9428526.html

动态图加载较慢，请稍后...

**V1.5增加新闻，菜谱等列表信息功能；**

![这里写图片描述](http://img.blog.csdn.net/20160520132529305)

**V1.4增加语音聊天及语音翻译及相关设置；**

![这里写图片描述](http://img.blog.csdn.net/20160519150322237)

**V1.3更换logo，增加首页分类菜单，内部webview，分享等；**

![这里写图片描述](http://img.blog.csdn.net/20160518130602905)![这里写图片描述](http://img.blog.csdn.net/20160518130845237)

![这里写图片描述](http://img.blog.csdn.net/20160518165247328)![这里写图片描述](http://img.blog.csdn.net/20160518165259004)![这里写图片描述](http://img.blog.csdn.net/20160518171647349)

**2016-05-17：增加讯飞语音设置入口，并优化封装讯飞语音相关代码！**

**V1.2增加语音识别及合成功能：**

![演示](http://img.blog.csdn.net/20160516141620589)

**V1.1 增加歌曲搜索功能：**

![演示](http://img.blog.csdn.net/20160513140525233)

**V1.0版本，可以和机器人对话，天气，星座，笑话，各种调侃等；**

1.首页，bannner轮播，资讯列表（资讯列表参考自网络抓取csdn资讯）！

2.消息，仿qq的聊天对话界面！

3.我的，1.0版本暂简单实现，设置（清空聊天记录），关于，退出等！

![登录](http://img.blog.csdn.net/20160512180054428)![首页](http://img.blog.csdn.net/20160512180110709)![消息](http://img.blog.csdn.net/20160512180142944)![我的](http://img.blog.csdn.net/20160512180128772)

![演示](http://img.blog.csdn.net/20160512181129051)

持续更新...

CSDN博客：http://blog.csdn.net/baiyuliang2013

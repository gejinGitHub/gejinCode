package com.byl.qrobot.db;

/**
 * 
 * @author 白玉梁
 */
public class DBcolumns {

	/**
	 * 聊天消息信息表
	 */
	public static final String TABLE_MSG= "table_msg";
	public static final String MSG_ID = "msg_id";
	public static final String MSG_FROM = "msg_from";
	public static final String MSG_TO = "msg_to";
	public static final String MSG_TYPE = "msg_type";
	public static final String MSG_CONTENT = "msg_content";
	public static final String MSG_ISCOMING = "msg_iscoming";
	public static final String MSG_DATE= "msg_date";
	public static final String MSG_ISREADED = "msg_isreaded";
	public static final String MSG_BAK1= "msg_bak1"; //现表示为音乐是否正在播放 1.正在播放 0或空.未播放
	public static final String MSG_BAK2 = "msg_bak2";
	public static final String MSG_BAK3 = "msg_bak3";
	public static final String MSG_BAK4= "msg_bak4";
	public static final String MSG_BAK5= "msg_bak5";
	public static final String MSG_BAK6= "msg_bak6";
	
}

package com.cniao5.app36kr_cnk.common;

/**
 * 项目数据常量配置
 * @author jiangqq
 *
 */
public class Config {
  public static final String CRAWLER_URL="http://www.36kr.com";
}

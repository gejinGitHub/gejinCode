﻿ [菜鸟新闻](http://www.cniao5.com)客户端是一个仿照36Kr官方,实 时抓取36Kr官网数据的资讯类新闻客户端。  
<br />包括首页新闻,详情,发现,活动,实时数据抓取,侧滑效果,第三方登录以及分享,消息推送等相关功能客户端。  
<br />视频和源码都分享出来了，有需要的话直接去下载  
<br />交流QQ群：**99787482**
<br />**下载**：
<br />课程地址：   http://www.cniao5.com/clazz/view/10076.html
<br />视频下载链接： http://pan.baidu.com/s/1eQLyQxc 密码：3ts1
<br /><br />**【运行截图】**
<br /><img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/cniaonews.gif" width="460" height="768"/>
<img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/pull_4 (2).gif" width="460" height="768"/>
<img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/Screenshot_2015-12-07-12-36-11.png" width="460" height="768"/>
<img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/Screenshot_2015-12-07-12-36-18.png" width="460" height="768"/>
<img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/Screenshot_2015-12-07-12-35-53.png" width="460" height="768"/>
<img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/Screenshot_2015-12-07-12-38-19.png" width="460" height="768"/>
<img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/Screenshot_2015-12-08-08-11-57.png" width="460" height="768"/>
<img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/Screenshot_2015-12-08-08-12-03.png" width="460" height="768"/>
<img src="https://github.com/yxs666/cniao5-news/blob/master/screenshot/Screenshot_2015-12-08-08-12-08.png" width="460" height="768"/>



